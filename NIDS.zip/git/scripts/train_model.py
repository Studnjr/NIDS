import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
import joblib
import numpy as np
import os

# Paths
DATA_PATH = "../data/preprocessed_dataset.csv"
MODEL_PATH = "../models/rf_nids_model.pkl"

print("Loading preprocessed dataset...")
df = pd.read_csv(DATA_PATH)

# Replace inf/-inf with NaN
df.replace([np.inf, -np.inf], np.nan, inplace=True)

# Drop rows with NaN
df.dropna(inplace=True)

print("Shape after removing inf/NaN:", df.shape)

# Features & Labels
X = df.drop('Label', axis=1).astype('float64')  # ensure float
y = df['Label']

# Train-test split (80% train, 20% test)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

print("Training RandomForestClassifier...")
rf = RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=-1)
rf.fit(X_train, y_train)

print("Training complete!")

# Predictions
y_pred = rf.predict(X_test)

# Evaluation
print("\nAccuracy:", accuracy_score(y_test, y_pred))
print("\nClassification Report:\n", classification_report(y_test, y_pred))
print("\nConfusion Matrix:\n", confusion_matrix(y_test, y_pred))

# Save model
os.makedirs("../models", exist_ok=True)
joblib.dump(rf, MODEL_PATH)
print("\nRandomForest model saved at:", MODEL_PATH)
