import os
import pandas as pd

# Path to your dataset folder
data_folder = "../data/"

# List all CSV files in the data folder
csv_files = [f for f in os.listdir(data_folder) if f.endswith(".csv")]

print("Found CSV files:")
for f in csv_files:
    print(" -", f)

# Merge all CSV files
df_list = []
for file in csv_files:
    path = os.path.join(data_folder, file)
    print("Loading:", file)
    df_list.append(pd.read_csv(path))

print("\nMerging all CSV files...")
merged_df = pd.concat(df_list, ignore_index=True)

print("Total rows:", len(merged_df))

# Save merged dataset
merged_df.to_csv("../data/dataset.csv", index=False)

print("\nMerged dataset saved at: data/dataset.csv")
