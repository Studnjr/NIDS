import pandas as pd
import joblib
import numpy as np

# Paths
MODEL_PATH = "../models/rf_nids_model.pkl"
DATA_PATH = "../data/preprocessed_dataset.csv"  # for testing, you can use a subset

# Load trained model
print("Loading RandomForest model...")
rf = joblib.load(MODEL_PATH)

# Load dataset (we can simulate "new network traffic")
df = pd.read_csv(DATA_PATH)

# Replace inf/-inf with NaN
df.replace([np.inf, -np.inf], np.nan, inplace=True)
df.dropna(inplace=True)

# Use only a small subset for demo
df_demo = df.sample(20, random_state=42)  # 20 random flows

X_demo = df_demo.drop('Label', axis=1).astype('float64')
y_demo = df_demo['Label']

# Predict
predictions = rf.predict(X_demo)

# Show results
print("\nSimulating real-time network traffic detection:")
for i, (pred, actual) in enumerate(zip(predictions, y_demo)):
    print(f"Flow {i+1}: Predicted = {pred}, Actual = {actual}")
