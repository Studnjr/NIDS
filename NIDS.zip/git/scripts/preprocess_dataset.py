import pandas as pd
import os

# Input and output paths
INPUT_CSV = "../data/dataset.csv"
OUTPUT_CSV = "../data/preprocessed_dataset.csv"

print("Loading dataset...")
df = pd.read_csv(INPUT_CSV)

print("Initial shape:", df.shape)

# Strip whitespace from column names
df.columns = df.columns.str.strip()

# Keep only relevant features
features = [
    'Flow Duration','Total Fwd Packets','Total Backward Packets',
    'Total Length of Fwd Packets','Total Length of Bwd Packets',
    'Fwd Packet Length Mean','Bwd Packet Length Mean',
    'Flow Bytes/s','Flow Packets/s','Fwd IAT Mean','Bwd IAT Mean',
    'Fwd PSH Flags','Fwd URG Flags','Bwd PSH Flags','Bwd URG Flags',
    'Protocol','Src Port','Dst Port','Label'
]

# Keep only features that exist in dataset
features = [f for f in features if f in df.columns]
df = df[features]

print("Shape after selecting features:", df.shape)

# Handle missing values
df = df.dropna()

# Convert Protocol to numeric if exists
protocol_map = {'TCP': 6, 'UDP': 17, 'ICMP': 1}
if 'Protocol' in df.columns:
    df['Protocol'] = df['Protocol'].apply(lambda x: protocol_map.get(str(x).upper(), 0))

# Convert Label: Binary Normal vs Attack
df['Label'] = df['Label'].apply(lambda x: 'Normal' if 'BENIGN' in str(x).upper() else 'Attack')

print("Label distribution:")
print(df['Label'].value_counts())

# Save preprocessed dataset
df.to_csv(OUTPUT_CSV, index=False)
print("Preprocessed dataset saved at:", OUTPUT_CSV)
