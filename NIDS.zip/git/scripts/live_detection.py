import pandas as pd
import numpy as np
import joblib
from scapy.all import rdpcap, IP, TCP, UDP

# Paths
MODEL_PATH = "../models/rf_nids_model.pkl"
PCAP_PATH = "../data/demo_traffic.pcap"  # your PCAP file

# Load trained RandomForest model
print("Loading RandomForest model...")
rf = joblib.load(MODEL_PATH)

# Get training column names (exact)
training_columns = rf.feature_names_in_

# Read PCAP
print(f"Reading PCAP file: {PCAP_PATH}")
packets = rdpcap(PCAP_PATH)

# Extract flows (simplified for demo)
flows = []
for pkt in packets:
    if IP in pkt:
        proto = pkt[IP].proto
        src_port = pkt.sport if TCP in pkt or UDP in pkt else 0
        dst_port = pkt.dport if TCP in pkt or UDP in pkt else 0
        pkt_len = len(pkt)
        flows.append({
            'Flow Duration': 0,
            'Total Fwd Packets': 1,
            'Total Backward Packets': 1,
            'Total Length of Fwd Packets': pkt_len,
            'Total Length of Bwd Packets': pkt_len,
            'Fwd Packet Length Mean': pkt_len,
            'Bwd Packet Length Mean': pkt_len,
            'Flow Bytes/s': pkt_len,
            'Flow Packets/s': 1,
            'Fwd IAT Mean': 0,
            'Bwd IAT Mean': 0,
            'Fwd PSH Flags': 0,
            'Fwd URG Flags': 0,
            'Bwd PSH Flags': 0,
            'Bwd URG Flags': 0,
            'Destination Port': dst_port,
            'Protocol': proto,
            'Src Port': src_port
        })

# Convert to DataFrame
df_flows = pd.DataFrame(flows)

# Replace inf/-inf
df_flows.replace([np.inf, -np.inf], np.nan, inplace=True)
df_flows.dropna(inplace=True)

# -------------------------------
# Align columns exactly as training
# -------------------------------
for col in training_columns:
    if col not in df_flows.columns:
        df_flows[col] = 0

df_flows = df_flows[training_columns]

# Convert to float
df_flows = df_flows.astype('float64')

# -------------------------------
# Predict
# -------------------------------
preds = rf.predict(df_flows)

# Show results
print("\nLive detection results:")
for i, pred in enumerate(preds):
    print(f"Packet {i+1}: Predicted = {pred}")
