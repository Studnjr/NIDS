import pandas as pd

df = pd.read_csv("../data/dataset.csv", nrows=5)
print("Columns in dataset:")
print(df.columns.tolist())