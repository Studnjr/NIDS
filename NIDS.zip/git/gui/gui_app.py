
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import joblib
import pandas as pd
import numpy as np
from scapy.all import rdpcap, IP, TCP, UDP
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.pyplot as plt
import os

MODEL_PATH = os.path.join("..", "models", "rf_nids_model.pkl")  

class NIDSModelGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("NIDS GUI — Model Integrated")
        self.root.geometry("1000x700")
        self.root.configure(bg="#1e1e1e")

        
        self.rf = None
        self.model_loaded = False
        self.feature_names = None
        self.load_model_on_startup()

        self.create_widgets()

    def load_model_on_startup(self):
        try:
            if not os.path.exists(MODEL_PATH):
                raise FileNotFoundError(f"Model not found at {MODEL_PATH}")
            self.rf = joblib.load(MODEL_PATH)
            
            if hasattr(self.rf, "feature_names_in_"):
                self.feature_names = list(self.rf.feature_names_in_)
            else:
                
                self.feature_names = None
            self.model_loaded = True
        except Exception as e:
            self.model_loaded = False
            print("Warning: model load failed:", e)
            

    def create_widgets(self):
        title = tk.Label(self.root, text="NIDS — Model Integrated GUI", font=("Segoe UI", 18, "bold"),
                         bg="#1e1e1e", fg="white")
        title.pack(pady=8)

        status_frame = tk.Frame(self.root, bg="#2a2a2a")
        status_frame.pack(fill="x", padx=10, pady=(0,10))

        self.model_status_label = tk.Label(status_frame,
                                           text=("Model loaded: Yes" if self.model_loaded else "Model loaded: No"),
                                           bg="#2a2a2a", fg="white", font=("Segoe UI", 11))
        self.model_status_label.pack(side="left", padx=10, pady=6)

        load_btn = tk.Button(status_frame, text="Load PCAP/PCAPNG", command=self.on_load_pcap,
                             bg="#4CAF50", fg="white")
        load_btn.pack(side="right", padx=10, pady=6)

        
        info_frame = tk.Frame(self.root, bg="#1e1e1e")
        info_frame.pack(fill="x", padx=10)

        self.total_label = tk.Label(info_frame, text="Total packets: 0", font=("Segoe UI", 12),
                                    bg="#1e1e1e", fg="white")
        self.total_label.grid(row=0, column=0, sticky="w", padx=6, pady=4)

        self.pred_attack_label = tk.Label(info_frame, text="Predicted Attacks: 0", font=("Segoe UI", 12),
                                          bg="#1e1e1e", fg="orange")
        self.pred_attack_label.grid(row=0, column=1, sticky="w", padx=6, pady=4)

        self.pred_normal_label = tk.Label(info_frame, text="Predicted Normal: 0", font=("Segoe UI", 12),
                                          bg="#1e1e1e", fg="lightgreen")
        self.pred_normal_label.grid(row=0, column=2, sticky="w", padx=6, pady=4)

        # Graph 
        graph_frame = tk.Frame(self.root, bg="#1e1e1e")
        graph_frame.pack(fill="both", expand=False, padx=10, pady=8)

        self.fig, self.ax = plt.subplots(figsize=(6,3))
        self.canvas = FigureCanvasTkAgg(self.fig, master=graph_frame)
        self.canvas.get_tk_widget().pack(fill="both", expand=True)

        # Alerts list
        bottom_frame = tk.Frame(self.root, bg="#1e1e1e")
        bottom_frame.pack(fill="both", expand=True, padx=10, pady=10)

        lbl = tk.Label(bottom_frame, text="Detected Alerts (packets predicted as 'Attack')",
                       bg="#1e1e1e", fg="white", font=("Segoe UI", 12, "bold"))
        lbl.pack(anchor="w")

        self.alerts_tree = ttk.Treeview(bottom_frame, columns=("idx","src","dst","sport","dport","pred"), show="headings", height=12)
        for c, w in [("idx",60), ("src",140), ("dst",140), ("sport",80), ("dport",80), ("pred",120)]:
            self.alerts_tree.heading(c, text=c.upper())
            self.alerts_tree.column(c, width=w, anchor="center")
        self.alerts_tree.pack(fill="both", expand=True, pady=6)

        # small footer
        footer = tk.Label(self.root, text="Tip: use small pcap files for faster tests (sample 100-1000 pkts).",
                          bg="#1e1e1e", fg="gray", font=("Segoe UI", 9))
        footer.pack(pady=(0,6))

    def on_load_pcap(self):
        path = filedialog.askopenfilename(title="Select PCAP/PCAPNG file", filetypes=[("pcap files","*.pcap *.pcapng")])
        if not path:
            return

        if not self.model_loaded:
            messagebox.showerror("Model not loaded", "Trained model not found. Make sure models/rf_nids_model.pkl exists.")
            return

        try:
            # Read pcap (scapy handles pcap; pcapng -> convert externally or use pyshark)
            packets = rdpcap(path)
        except Exception as e:
            messagebox.showerror("Error reading PCAP", f"Cannot read file: {e}")
            return

        # Basic protocol counting
        tcp = udp = icmp = other = 0
        flows = []
        for i, pkt in enumerate(packets):
            # limit for very big files — you can remove this line if you want whole file
            # if i >= 5000: break

            if IP not in pkt:
                other += 1
                continue

            if pkt.haslayer("TCP"):
                tcp += 1
            elif pkt.haslayer("UDP"):
                udp += 1
            elif pkt.haslayer("ICMP"):
                icmp += 1
            else:
                other += 1

            # Build the same lightweight feature set per packet used earlier
            proto = pkt[IP].proto
            src_port = pkt.sport if (pkt.haslayer("TCP") or pkt.haslayer("UDP")) else 0
            dst_port = pkt.dport if (pkt.haslayer("TCP") or pkt.haslayer("UDP")) else 0
            pkt_len = len(pkt)

            # Create flow-like single-packet row (same fields used in training)
            row = {
                'Flow Duration': 0,
                'Total Fwd Packets': 1,
                'Total Backward Packets': 1,
                'Total Length of Fwd Packets': pkt_len,
                'Total Length of Bwd Packets': pkt_len,
                'Fwd Packet Length Mean': pkt_len,
                'Bwd Packet Length Mean': pkt_len,
                'Flow Bytes/s': pkt_len,
                'Flow Packets/s': 1,
                'Fwd IAT Mean': 0,
                'Bwd IAT Mean': 0,
                'Fwd PSH Flags': 0,
                'Fwd URG Flags': 0,
                'Bwd PSH Flags': 0,
                'Bwd URG Flags': 0,
                # Many training sets had slightly different column names (spaces); we'll align below using model.feature_names_in_
                'Destination Port': dst_port,
                'Protocol': proto,
                'Src Port': src_port
            }
            flows.append(row)

        total = len(packets)
        self.total_label.config(text=f"Total packets: {total}")
        self.pred_attack_label.config(text=f"Predicted Attacks: computing...")
        self.pred_normal_label.config(text=f"Predicted Normal: computing...")

        # Convert flows to DataFrame
        if len(flows) == 0:
            messagebox.showinfo("No IP packets", "No IP packets were found in the chosen file.")
            return
        df = pd.DataFrame(flows)

        # Replace infinities and drop nulls
        df.replace([np.inf, -np.inf], np.nan, inplace=True)
        df.dropna(inplace=True)

        # Align columns exactly as training model expects (names + order)
        train_cols = list(self.feature_names) if self.feature_names is not None else None
        if train_cols is None:
            messagebox.showerror("Model metadata missing",
                                 "Model doesn't expose feature_names_in_. Cannot align features automatically.")
            return

        # Add missing columns with zeros and reorder
        for c in train_cols:
            if c not in df.columns:
                df[c] = 0
        df = df[train_cols]

        # Ensure numeric dtype
        df = df.astype('float64')

        # Predict
        try:
            preds = self.rf.predict(df)
        except Exception as e:
            messagebox.showerror("Prediction error", f"Model prediction failed: {e}")
            return

        # Summarize predictions
        df_results = df.copy()
        df_results['pred'] = preds

        attack_count = int((df_results['pred'] != 'Normal').sum())
        normal_count = int((df_results['pred'] == 'Normal').sum())
        self.pred_attack_label.config(text=f"Predicted Attacks: {attack_count}")
        self.pred_normal_label.config(text=f"Predicted Normal: {normal_count}")

        # Draw protocol distribution
        self.ax.clear()
        labels = ["TCP", "UDP", "ICMP", "Other"]
        values = [tcp, udp, icmp, other]
        self.ax.bar(labels, values, color=["#3498db","#f39c12","#9b59b6","#95a5a6"])
        self.ax.set_title("Protocol distribution")
        self.ax.set_ylabel("Count")
        self.canvas.draw()

        # Populate alerts table with packets predicted as Attack
        # Clear existing rows
        for row in self.alerts_tree.get_children():
            self.alerts_tree.delete(row)

        attack_rows = df_results[df_results['pred'] != 'Normal']
        # show up to first 500 alerts to avoid UI freeze
        for idx, (_, r) in enumerate(attack_rows.iterrows()):
            if idx >= 500: break
            src = int(r.get('Src Port', 0))
            dst = int(r.get('Destination Port', 0))
            # We do not have IP addresses in this per-packet simplified flow.
            self.alerts_tree.insert("", "end", values=(idx+1, "unknown", "unknown", src, dst, r['pred']))

        messagebox.showinfo("Done", f"Analysis complete — {attack_count} attacks detected (showing up to 500).")

def main():
    root = tk.Tk()
    app = NIDSModelGUI(root)
    root.mainloop()

if __name__ == "__main__":
    main()
